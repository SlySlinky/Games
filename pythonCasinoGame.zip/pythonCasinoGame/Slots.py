class Slots:
    
    bet = 0
    theroll1 = 0
    theroll2 = 0
    theroll3 = 0
    def __init__(self, bet):
        self.bet = bet
        
    def spinknobs(self, roll1, roll2, roll3):
        self.theroll1 = roll1
        self.theroll2 = roll2
        self.theroll3 = roll3
