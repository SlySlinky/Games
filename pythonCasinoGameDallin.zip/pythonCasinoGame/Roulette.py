class Roulette:
    x = ''
    y = ''
    bet_types = {
    '0': 35,
    '00': 35,
    'even': 1,
    'odd': 1,
    '1 to 18': 1,
    '19 to 36': 1,
    '1st 12': 2,
    '2nd 12': 2,
    '3rd 12': 2,
    }
    outcomes = {
    '0': ['0'],
    '00': ['00'],
    '1': ['1 to 18', 'odd'],
    '2': ['even'],
    '3': ['1 to 18', 'odd'],
    '4': ['even'],
    '5': ['1 to 18', 'odd'],
    '6': ['even'],
    '7': ['1 to 18', 'odd'],
    '8': ['even'],
    '9': ['19 to 36', 'odd'],
    '10': ['even'],
    '11': ['19 to 36', 'odd'],
    '12': ['1st 12'],
    '13': ['2nd 12'],
    '14': ['1st 12'],
    '15': ['2nd 12'],
    '16': ['1st 12'],
    '17': ['2nd 12'],
    '18': ['1st 12', 'even'],
    '19': ['2nd 12', 'odd'],
    '20': ['1st 12', 'even'],
    '21': ['2nd 12', 'odd'],
    '22': ['1st 12', 'even'],
    '23': ['2nd 12', 'odd'],
    '24': ['1st 12', 'even'],
    '25': ['2nd 12', 'odd'],
    '26': ['3rd 12', 'even'],
    '27': ['19 to 36', 'odd'],
    '28': ['even'],
    '29': ['1 to 18', 'odd'],
    '30': ['even'],
    '31': ['1 to 18', 'odd'],
    '32': ['even'],
    '33': ['1 to 18', 'odd'],
    '34': ['even'],
    '35': ['19 to 36', 'odd'],
    '36': ['even']
    }
    ok = 0
    def __init__(self, ok):
        self.ok = ok
        
    def spin_wheel(self):
        self.outcomes = outcomes
        outcome = random.choice(list(outcomes.keys()))
        print('The ball landed on', outcome)
        return outcome
    def resolve_bet(self,x,y,outcome,bal):
        self.x = x
        self.y = y
        self.outcome = outcome
        if y in outcomes[outcome]:
            payout = x * bet_types[y]
            print('You won', payout)
            bal += payout
            balance = bal
            print(balance)
            print("")
            print("")
            return payout
        else:
            print('You lost')
            bal -= bet_amount
            balance = bal
            print(balance)
            print("")
            print("")
            return x
